<<?php echo esc_attr($title_tag); ?> class="eltdf-custom-font-holder" <?php azalea_eltdf_inline_style($holder_styles); ?> <?php echo esc_attr($holder_data); ?>>
	<?php echo esc_html($title); ?>
</<?php echo esc_attr($title_tag); ?>>