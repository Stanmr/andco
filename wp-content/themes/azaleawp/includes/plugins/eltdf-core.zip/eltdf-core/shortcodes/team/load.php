<?php
include_once ELATED_CORE_SHORTCODES_PATH.'/team/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/team/team-list.php';