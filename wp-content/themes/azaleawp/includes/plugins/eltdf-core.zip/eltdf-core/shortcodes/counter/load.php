<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/counter/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/counter/counter.php';