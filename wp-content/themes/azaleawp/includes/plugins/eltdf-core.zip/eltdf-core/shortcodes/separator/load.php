<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/separator/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/separator/separator.php';