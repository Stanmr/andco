<div class="eltdf-parallax-holder <?php echo esc_attr($holder_class); ?>" <?php echo azalea_eltdf_get_inline_attrs($holder_data); ?> <?php echo azalea_eltdf_get_inline_style($holder_style); ?>>
	<div class="eltdf-parallax-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
