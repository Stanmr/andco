<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/banner/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/banner/banner.php';