<div class="eltdf-fss-item <?php echo esc_attr($holder_classes); ?>" <?php azalea_eltdf_inline_style($holder_styles); ?>>
	<div class="eltdf-fss-item-inner" <?php azalea_eltdf_inline_style($item_inner_styles); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>