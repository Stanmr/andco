<?php

get_header();

azalea_eltdf_get_title();

eltdf_core_single_proofing_gallery();

get_footer();