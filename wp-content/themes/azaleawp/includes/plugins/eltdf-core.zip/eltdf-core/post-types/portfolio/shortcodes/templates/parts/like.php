<?php if ($enable_like === 'yes') { ?>
<div class="eltdf-portfolio-like">
    <?php if( function_exists('azalea_eltdf_get_like') ) azalea_eltdf_get_like(); ?>
</div>
<?php } ?>
