<?php if(azalea_eltdf_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>