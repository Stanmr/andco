<div class="eltdf-ps-info-item eltdf-ps-content-item">
    <h2 class="eltdf-ps-title"><?php the_title(); ?></h2>
    <?php echo azalea_eltdf_execute_shortcode("eltdf_separator", array("width" => "54", "thickness" => "2", "position" => "left" )); ?>
    <?php the_content(); ?>
</div>