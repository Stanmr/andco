<?php

include_once ELATED_CORE_CPT_PATH.'/proofing-gallery/proofing-gallery-register.php';
include_once ELATED_CORE_CPT_PATH.'/proofing-gallery/helper-functions.php';
include_once ELATED_CORE_CPT_PATH.'/proofing-gallery/shortcodes/shortcodes-functions.php';